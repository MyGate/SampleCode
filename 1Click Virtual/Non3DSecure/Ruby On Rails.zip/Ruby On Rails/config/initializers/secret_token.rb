# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Mygate::Application.config.secret_token = '102f61b1af39a94162fb789ef8c144f5158f001e730f65e493305cd2461c0553c4970efb915b00f2e323e845bee372787b6da40f18856b830142940c65d41d56'
