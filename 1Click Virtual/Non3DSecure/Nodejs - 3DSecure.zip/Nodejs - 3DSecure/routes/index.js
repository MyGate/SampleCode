var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function (req, res, next) {

    var Mode = "0";
    var MerchantID = "F5785ECF-1EAE-40A0-9D37-93E2E8A4BAB3";
    var ApplicationID = "1DBBBAAE-958E-4346-A27A-6BB5171CEEDC";
    var Price = "12.34";
    var Currency = "ZAR";
	var ClientToken = "YourUniqueToken";
    var MerchantReference = "My Merchant Ref #";
    var RedirectSuccess = "http://localhost:3000/process";
    var RedirectFailed = "http://localhost:3000/process";

    res.render('index',
        {
            Title: 'Node.JS Virtual 3D Secure',
            Mode: Mode,
            MerchantID: MerchantID,
            ApplicationID: ApplicationID,
            Price: Price,
            Currency: Currency,
			ClientToken: ClientToken,
            MerchantReference: MerchantReference,
            RedirectSuccess: RedirectSuccess,
            RedirectFailed: RedirectFailed
        });

});

router.all('/process', function (req, res, next) {

    var result = req.body._RESULT;

    if (result >= 0)
        res.render('process-success',
            {
                Title: 'Node.JS Virtual 3D Secure',
                result: result,
                threedsecure: req.body._3DSTATUS,
                acquirerDateTime: req.body._ACQUIRERDATETIME,
                price: req.body._AMOUNT,
                cardCountry: req.body._CARDCOUNTRY,
                countryCode: req.body._COUNTRYCODE,
                currencyCode: req.body._CURRENCYCODE,
				ClientToken: req.body._CLIENTTOKEN,
                merchantReference: req.body._MERCHANTREFERENCE,
                transactionIndex: req.body._TRANSACTIONINDEX,
                payMethod: req.body._PAYMETHOD
            });
    else
        res.render('process-failed',
            {
                Title: 'Node.JS Virtual 3D Secure',
                result: result,
                errorCode: req.body._ERROR_CODE,
                errorMessage: req.body._ERROR_MESSAGE,
                errorDetail: req.body._ERROR_DETAIL,
                errorSource: req.body._ERROR_SOURCE,
                bankErrorCode: req.body.__BANK_ERROR_CODE,
                bankErrorMessage: req.body.__BANK_ERROR_MESSAGE
            });
});

module.exports = router;
