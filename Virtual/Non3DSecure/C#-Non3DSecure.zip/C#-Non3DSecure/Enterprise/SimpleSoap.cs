﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Virtual
{
    class SimpleClient
    {
        public string response = "";

        public SimpleClient()
        {

        }

        public string processResults(string body)
        {
            response = "";

            Dictionary<string, string> parameters = new Dictionary<string, string>();

            string[] par = body.Split('&');
            if (par.Length > 0)
                foreach (string p in par)
                {
                    string[] temp = p.Split('=');
                    if (temp.Length == 2)
                    {
                        parameters[temp[0]] = temp[1];
                    }
                }

            //The _RESULT element of the form post is the transaction result.
            //   0=Successful
            //   1=Warning
            //
            // (A result of 1 is returned either when the fraud module is providing a flag
            //  or if unnecessary parameters were sent to the API in the request message).
            //
            // Note: A result code of 1 is still a successful transaction.

            if ( Int32.Parse(parameters["_RESULT"]) >= 0 ) 
            {
                response += "Successful Transaction" + "<br/>";
                response += "Result: " + parameters["_RESULT"] + "<br/>";
                response += "3D-Secure Status: " + parameters["_3DSTATUS"] + "<br/>";
                response += "Processed Amount: " + parameters["_AMOUNT"] + "<br/>";
                response += "Card Country: " + parameters["_CARDCOUNTRY"] + "<br/>";
                response += "Country Code: " + parameters["_COUNTRYCODE"] + "<br/>";
                response += "Currency Code: " + parameters["_CURRENCYCODE"] + "<br/>";
                response += "Merchant Reference: " + parameters["_MERCHANTREFERENCE"] + "<br/>";
                response += "Transaction Index: " + parameters["_TRANSACTIONINDEX"] + "<br/>";
                response += "Pay Method: " + parameters["_PAYMETHOD"] + "<br/>";
            }
            else 
            {
                // In the event of a failed transaction, most merchants will only display
                // the bank error message to the client as this will often give the most
                // descriptive message relevant to the client.
                //  E.g. Insufficient funds, Blocked Card, etc.
                response += "Failed Transaction" + "<br/>";
                response += "Result: " + parameters["_RESULT"] + "<br/>";
                response += "Error Code: " + parameters["_ERROR_CODE"] + "<br/>";
                response += "Error Message: " + parameters["_ERROR_MESSAGE"] + "<br/>";
                response += "Error Details: " + parameters["_ERROR_DETAIL"] + "<br/>";
                response += "Error Source: " + parameters["_ERROR_SOURCE"] + "<br/>";
                response += "Bank Error Code: " + parameters["_BANK_ERROR_CODE"] + "<br/>";
                response += "Bank Error Message: " + parameters["_BANK_ERROR_MESSAGE"] + "<br/>";
            }
            
            return response;
        }
        public string sample () {

            response = "";

            // Setting variables that get sent to MyGate
            string URL  = "https://virtual.mygateglobal.com/PaymentPage.cfm";
            string Mode = "0";     // 0 = Test Mode. 1 = Live Mode

            
            string MerchantID    = "F5785ECF-1EAE-40A0-9D37-93E2E8A4BAB3";
            string ApplicationID = "1DBBBAAE-958E-4346-A27A-6BB5171CEEDC";

            // Currency and price of transaction
            string Price   = "10.00";
            string Currency = "USD";

            // Redirect Details
            string RedirectSuccess = "http://localhost:8080/processResults";
            string RedirectFailed  = "http://localhost:8080/processResults";

            string MerchantReference  = "MyMerchantRef1";

            response += @"<head><title>MyVirtual Example</title>
                    <meta name=""Copyright"" content=""MyGate Communications (Pty) Ltd 2007"" />
                    <meta http-equiv=""Content-Type"" content=""text/html; charset=utf-8"" />
                    </head>
                    <body>
                    <h1>My Virtual Example</h1>
                    <form method=""post"" action=""" + URL + @""" enctype=""multipart/form-data"" name=""Virtual Post"">
                    
                    <input type=""hidden"" name=""Mode"" value=""" + Mode + @"""  /><br />
                    <input type=""hidden"" name=""txtMerchantID"" value=""" + MerchantID + @"""  /><br />
                    <input type=""hidden"" name=""txtApplicationID"" value=""" + ApplicationID + @"""  /><br />
                    <input type=""hidden"" name=""txtMerchantReference"" value=""" + MerchantReference + @"""  /><br />
                    <input type=""hidden"" name=""txtRedirectSuccessfulURL"" value=""" + RedirectSuccess + @"""  /><br />
                    <input type=""hidden"" name=""txtRedirectFailedURL"" value=""" + RedirectFailed + @"""  /><br />
                    
                    Amount: R<input type=""text"" name=""txtPrice"" value=""" + Price + @""" /><br />
                    
                    <input type=""hidden"" name=""txtCurrencyCode"" value=""" + Currency + @"""  /><br />
                    <input type=""hidden"" name=""txtDisplayPrice"" value=""" + Price + @"""  /><br />
                    <input type=""hidden"" name=""txtDisplayCurrencyCode"" value=""" + Currency + @"""  /><br />
                    <input type=""submit"" name=""submit"" value=""Process Transaction"" /><br /></form>
                    </body>
                    </html>";

            return response;

        }
    }
}
