--------------------------------------------------------------------------------
DOCUMENTATION
--------------------------------------------------------------------------------

This code sample has been successfully tested on the following server
configurations and performed according to MyGate's documented My Virtual integration method standards.
  Ruby v1.9 on Rails v3.1.3 with MySQL v5.5.9, railties and RVM v1.9.3 on Mac OS X 10.7.4


--------------------------------------------------------------------------------
DISCLAIMER
--------------------------------------------------------------------------------

WARNING: ANY USE BY YOU OF THE SAMPLE CODE PROVIDED IS AT YOUR OWN RISK

MyGate provides this code "as is" without warranty of any kind, either
express or implied, including but not limited to the implied warranties of
suitability and/or fitness for a particular purpose.

This sample code is provided merely as a blueprint demonstrating one possible
approach to integrating with MyGate using our My Virtual integration
Method.

This sample code is not a tutorial.  If you are unfamiliar with specific
programming functions and concepts, please consult the appropriate reference
materials.

--------------------------------------------------------------------------------
PREREQUISITES
--------------------------------------------------------------------------------
- This sample code uses an HTTP POST to establish a connection
  to the MyGate server.

- It is required that you edit the database.yml file located in the config directory of the sample root. This contains the database settings that are needed for the db:create command below.

- It is required that you already have the following running in your environment:

  1) Ruby on Rails
  2) MySQL Server
  3) railties
  4) RVM 1.9.3

  Once you have the above installed, cd to where the MyGate sample code is and run the following commands:

  1) rvm use 1.9.3
  2) bundle install
  3) rake db:create
  4) rails s

  The last command will start the rails server on your local machine. Once this successful, you can browse to the sample by going to: http://0.0.0.0:3000


