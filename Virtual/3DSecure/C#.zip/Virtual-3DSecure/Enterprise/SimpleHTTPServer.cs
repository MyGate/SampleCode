﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Collections.Specialized;
using System.IO;
using System.Net;
using System.Reflection;
using System.Threading;

namespace Virtual
{
 class Worker
 {
    
       private HttpListenerContext context;
 
        public Worker(HttpListenerContext context)
       {
           this.context = context;
        }
  
        public void ProcessRequest()
        {
           string msg = context.Request.HttpMethod + " " + context.Request.Url;
           Console.WriteLine(msg);

           var body = new StreamReader(context.Request.InputStream).ReadToEnd();
           
           SimpleClient client = new SimpleClient();
           string response = "";
           if (context.Request.RawUrl == "/processResults")
           {
               response = client.processResults(body);
           }
           else
           {
               response = client.sample();
           }

           StringBuilder sb = new StringBuilder();
           sb.Append("<html><body><h1>" + msg + "</h1>");
           sb.Append(response);
           sb.Append("</body></html>");

           try
           {
               byte[] b = Encoding.UTF8.GetBytes(sb.ToString());
               context.Response.ContentLength64 = b.Length;
               context.Response.OutputStream.Write(b, 0, b.Length);
               context.Response.OutputStream.Close();
           }
           catch (Exception e)
           {
               Console.WriteLine(e.Message);
           }

        }
    }
 }