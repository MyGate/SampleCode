var express = require('express');
var https = require('https');
var soap = require('soap');

var router = express.Router();

var text = "";
var actionResponse;
var authResponse;

/* GET home page. */
router.all('/', function (req, res, next) {

    /******************************************************************************************************/

    var merchantUID = 'F5785ECF-1EAE-40A0-9D37-93E2E8A4BAB3';
    var merchantToken = 'F5785ECF-1EAE-40A0-9D37-93E2E8A4BAB3';
    var applicationUID = "5A02E47D-7E2E-452B-A940-E3E946265037";
	
	//	A06033E6-43CF-471A-A985-E16442ED1FFF
    //  5A02E47D-7E2E-452B-A940-E3E946265037    - 3d
	
	//		Action	Action Name
    //		1		Authorise
    //		2		Authorise - Reversal
    //		3		Capture
    //		4		Credits (Follow-On)
    //		5		Sale
    //		12		Credits - Sale
    //		14		ThreeD Secure - Lookup
    //		15		ThreeD Secure - Authenticate
    //		19		Reports

    var actionTypeID = "1";

    var dateFormatted = new Date;
    var dformat = [dateFormatted.getFullYear(),
            dateFormatted.getMonth() + 1,
            dateFormatted.getDate()].join('') + '_' +
        [dateFormatted.getHours(),
            dateFormatted.getMinutes(),
            dateFormatted.getSeconds()].join('');

    var replace = {
        mode: '0',
        applicationUID: applicationUID,
        transactionIndex: '00000000-0000-0000-0000-000000000000',
        merchantReference: 'merchantReference_' + dformat,
        token: '19AF3483-DE0A-4BC1-B1B8-650E45EFA700',
        cvvNumber: '123',
        amount: '10.36',
        verbalAuthCode: '123456',
        paresPayload: ''
    };

    function renderResult(actionTypeID, isAction) {

        if (isAction) {
            text += "<br><b>=================================================</b><br>";
            text += "<b>Action " + actionTypeID + " Response</b>";
            text += "<br><b>=================================================</b><br>";
            text += "<pre>" + entities.encode(JSON.stringify(actionResponse)).replace(/,/g,",<br/>") + "</pre>";
            text += "<br><b>=================================================</b><br>";
        }

        res.render('index', {title: 'Enterprise 3D Non Secure', output: text});
        text = "";

    };

    function processRequest(merchantUID, merchantToken, actionTypeID, replace, callback) {

        var ns = "https://api.mygateglobal.com/";
        var url = ns + 'api/api.wsdl';
        var resultProcess = "";

        var Entities = require('html-entities').XmlEntities;
        entities = new Entities();

        /*
         * The xml files here are only used as an example. It should be changed to the requirements of the customer.
         * The sample xml can be downloaded from https://github.com/MyGateGlobal/SampleCode/tree/master/XML%20Actions
         * or generated according to specifications on https://developers.mygateglobal.com
         */

        var fileurl = ns + 'api/xmlactions/action_' + actionTypeID + '_Tokenization.xml';
        https.get(fileurl, function (res) {

            res.on("data", function (xml) {
                var xmlRequest = "" + xml;
                var search = ['mode', 'applicationUID', 'transactionIndex', 'merchantReference', 'token', 'cvvNumber', 'amount', 'verbalAuthCode', 'paresPayload'];
                search.forEach(function (el) {
                    xmlRequest = xmlRequest.replace("{" + el + "}", replace[el]);
                });

                text += "<b>Submission Data for action :" + actionTypeID + "</b>";
                text += "<br><b>=================================================</b><br>";
                text += "<pre>" + xmlRequest + "</pre>";
                text += "<br><b>=================================================</b><br>";

                var soapHeader =
                    "<authenticate>" +
                    "<merchantUID>" + merchantUID + "</merchantUID>" +
                    "<merchantToken>" + merchantToken + "</merchantToken>" +
                    "<actionTypeID>" + actionTypeID + "</actionTypeID>" +
                    "</authenticate>";

                soap.createClient(url, function (err, client) {

                    var Entities = require('html-entities').XmlEntities;
                    entities = new Entities();
                    //xmlRequest = "<tns:requestMessage>" + entities.encode(xmlRequest) + "</tns:requestMessage>";

                    client.addSoapHeader(soapHeader);
                    client.execRequest(xmlRequest, function (err, result) {
                        if (err) throw err;
                        callback(result);
                    });
                });
            });
        }).on('error', function (e) {
            console.log("Got error: " + e.message);
        });
    }; 


});

module.exports = router;

